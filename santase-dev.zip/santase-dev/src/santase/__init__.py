"""A package for implementing bots playing the Schnapsen card game"""

from schnapsen.game import Bot, PlayerPerspective, Move, SchnapsenTrickScorer, Talon, Previous, GameState
from schnapsen.deck import Suit, Card, Rank
from typing import Optional
import random



#### gene encoding ####
# [
# [[number]],    #number between 0 and 66 (number of points)
# [[1,1,1,0,0]], #variation of 1,0 (depending on how many of the cards have been seen)
# [[number2]]    #number between 0 and 66 (number of points)
# ]

#### fitness function ####
#How many times that bot variation wins

#### mutation ####
# Index:    Mutation:
# 0         +/- 1 point
# 1         Binary addition ?
# 2         +/- 1 point

#### survivor selection ####
# Concat new population and old population
# Concat new fitness and old fitness
# argsort both lists based on fitness
# use the first half of sorted list

#### evaluation ####
# Evaluate using loss function

#### Notes ####

#Basic bot to compare as a baseline
#Or play against rand bot???

#set seed to reproduce results and keep the same

#find which strategy is the best by turning the other ones off.

class OurBot(Bot):
    def __init__(self) -> None:
        print("See stan this code runs")
        self.seed = 123
        self.rng = random.Random(self.seed)

    def get_move(
        self,
        state: PlayerPerspective,
        leader_move: Optional[Move],
    ) -> Move:
        moves: list[Move] = state.valid_moves()
        move = self.rng.choice(list(moves))
        return move

    def __repr__(self) -> str:
        return f"RandBot(seed=)"

    def marriage_and_trump_exchange(valid_moves, new_trump: Card) -> Card:
        #treshhold variable genetic
        trump_exchange_list = []
        for move in valid_moves:
            if move.is_trump_exchange():
                assert new_trump.rank is Rank.JACK
                assert len(self._cards) >= 2
                assert new_trump.suit is self._cards[-1].suit
                old_trump = self._cards.pop(len(self._cards) - 1)
                self._cards.append(new_trump)
                return old_trump
        
        # for move in valid_moves:
        #     move.is_marriage() 


# class OurBot(Bot):


#     def get_move(self, encode, state: 'PlayerPerspective', leader_move: Optional['Move']) -> 'Move':

#         valid_moves = state.valid_moves()
#         trumpSuit = state.get_trump_suit()

#         move = self.random.choice(list(valid_moves))
        
 
#         OurBot.close_the_deck(variation)
        
#         OurBot.remember_cards_strategy(encode)
        

#         return move


#     def marriage_and_trump_exchange(valid_moves):

#         ### Trump exchange:
#         #(add some random factor as to show marriage/trump)
#         #jack exchange as early as possible

#         ### Marriage:
#         #(add some random factor as to show marriage/trump)
#         #Show marriage or trump early on
#         #When oppoenent is on lead trump early on to gain a lead and dispose of marriage

#         #***Similarly, 
#         # your natural unwillingness to trump with the jack decreases your number of playable cards. ****

#         #Exception:
#         #You dont wanna give up lead by showing a marriage
#         #if Bot is leading with 33-45 points in tricks, has a marriage, and trump ace
#         #Then lead trump as first, so you have atleast 46. Then show the marriage to win

       
#         # *****As another simple example, the stock is closed and you are on lead holding a marriage and the top trumps. 
#         # If your opponent holds neither the ace nor ten of your marriage suit, 
#         # you “pull” (i.e., extract) your opponent’s trumps before showing the marriage, 
#         # in order to avoid having your marriage cards trumped.******
#         print("marriage and trump exchange strategy")

    
#     def early_on_lead_strategy(state: 'PlayerPerspective', valid_moves, trumpSuit, pointsThreshold):
#         moveList = []

#         #early in game:
#         #if youve seen its marriage partner played:
#         # better to lead a non trump jack, queen or king

#         if state.am_i_leader() == True:
#             if bot.points < pointsThreshold:
#                 for move in valid_moves:
#                     if move.card.suit != trumpSuit.card.suit:
#                         if move.card.rank == jack:
#                             moveList.append(move)
#                         if move.card.rank == queen:
#                             moveList.append(move)
#                         if move.card.rank == king:
#                             moveList.append(move)
            
#             if len(moveList) != 0:
#                 #play lowest ranking card
#                 print("play lowest ranking card")




#         #with adjacent cards, lead the lower card
#         #(for example, ten-king, or queen-jack, or ten-queen when the king has already been played), : 
#         # lead the lower one. To give fewer trick points to oponent

#         # You do not usually want to lead a trump at this stage, 
#         # because your opponent is under no obligation to follow suit and give up a valuable trump. 
#         # A simple and passive strategy is to lead a nontrump jack, 
#         # or a queen or king where you have already seen its marriage partner played.
#         #  
#         # You expect your opponent to be able to win this trick, 
#         # but you are giving up very few trick points from your hand. 
        
#         # From “adjacent” cards in a suit 
#         # (for example, ten-king, or queen-jack, or ten-queen when the king has already been played), 
#         # lead the lower card, in order to give up fewer trick points to your opponent.



#         print("When you are on lead")

    

#     def phase_2_strategy(variation):
#         #both players must follow suit and must trump if they cannot follow suit. 

#         #if bot has more trumps and higher trumps than opponent:
#         #play highest trumps until opponent no longer has trumps.
#         #then play highest non trumps

#         #if not leading then trump if its the only way to win the trick.


#         #if opponent has trumps bot cannot pull:
#         #play suit that the oppponent does not have.
#         print("close the deck strategy")






        
